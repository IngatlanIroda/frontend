
import React from 'react'
import Navbars from "../components/Navbars";
import useAuthContext from "../contexts/AuthContext";

const KIjelentkezes = () => {
  return (
    <>
    <Navbars/>
    <div>Kijelentkezes</div>
    </>
  )
}

export default KIjelentkezes