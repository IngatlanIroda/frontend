import React from 'react'
import Navbars from './Navbars'

const Hirdetes = () => {
  return (
    <>
    <Navbars/>
    <div>Hirdetes</div>
    </>
   
  )
}

export default Hirdetes